/**
 * CityLogic Theme Custom Admin Functionality
 *
 */
( function( $ ) {
	
    $( document ).ready( function() {
    });

} )( jQuery );
