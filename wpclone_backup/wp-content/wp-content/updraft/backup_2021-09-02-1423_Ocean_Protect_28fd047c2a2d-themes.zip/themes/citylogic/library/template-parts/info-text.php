<div class="info-text">
	<?php echo wp_kses_post( pll__( get_theme_mod( 'citylogic-header-info-text-one', customizer_library_get_default( 'citylogic-header-info-text-one' ) ) ) ); ?>
</div>