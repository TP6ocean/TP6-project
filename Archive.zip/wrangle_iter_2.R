library(dplyr)
library(ggplot2)
zip_code <- read.csv("Australian_Post_Codes_Lat_Lon.csv")
net <- read.csv("nettows_info_wrangle.csv")


zip_code <- zip_code[!is.na(zip_code$lon),]

testa <- read.csv("testa.csv")
testb <- read.csv("testb.csv")
library(geosphere)
#testa$dist = rowwise() %>% distm (c(testa$StartLatitude, testa$StartLongitude), c(testb$lat, testb$lon), fun = distHaversine)


info_zip <- data.frame(zip_code$state,zip_code$lat,zip_code$lon)

df = merge(x = net, y = info_zip , by = NULL)
#write.csv(df,"check.csv", row.names = FALSE)
#test<-is.na(df)
df <- df[!is.na(df$StartLatitude),]
write.csv(df,"check.csv", row.names = FALSE)

earth.dist <- function (long1, lat1, long2, lat2)
{
  rad <- pi/180
  a1 <- lat1 * rad
  a2 <- long1 * rad
  b1 <- lat2 * rad
  b2 <- long2 * rad
  dlon <- b2 - a2
  dlat <- b1 - a1
  a <- (sin(dlat/2))^2 + cos(a1) * cos(b1) * (sin(dlon/2))^2
  c <- 2 * atan2(sqrt(a), sqrt(1 - a))
  R <- 6378.145
  d <- R * c
  return(d)
}

df$distance = 0

for(i in 1:nrow(df)) {       # for-loop over rows
  #df$distance <- earth.dist(df[i, 1],df[i, 2],df[i, 13],df[i, 14])
  val <- earth.dist(df[i, 1],df[i, 2],df[i, 13],df[i, 14])
  df[i,15] <- val
}

#write.csv("testting.csv", row.names = FALSE)



write.csv(df,"testting.csv", row.names = FALSE)

final_df <- read.csv("testting.csv")

df<-final_df[final_df$distance != 0, ]

tmp <- setDT(df)[, .(distance = min(distance)), by = StartLongitude]
DT <- df[tmp, on = .(StartLongitude, distance), mult = "first"]
write.csv(DT,"out.csv", row.names = FALSE)

out <- read.csv("out.csv")

drops <- c("Cs")
im <- out[ , !(names(out) %in% drops)]
im <- im %>% 
  group_by(zip_code.state) %>% 
  summarise(across(everything(), sum))
drop_a <- c("zip_code.state","Cs")

Cs <- out %>% select(zip_code.state,Cs)
Cs <- aggregate(Cs$Cs, by=list(Cs$zip_code.state), FUN=mean)

names(Cs)[1] <- 'State'
names(Cs)[2] <- 'Avg_Cs'
names(im)[1] <- 'State'
library(sqldf)

## inner join
fin <- sqldf("SELECT *
              FROM im
              JOIN Cs USING(State)")


write.csv(fin,"out.csv", row.names = FALSE)

