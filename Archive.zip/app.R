library(shiny)
library(shinyBS)
library(shinydashboard)
library(shinycssloaders)
library(plotly)
library(tidyverse)
library(DT)
library(shinyWidgets)
library(leaflet)
library(data.table)
library(fmsb)
library(dplyr)
library(flexdashboard)
library(shinythemes)

# Define UI for application that draws a histogram
ui <- fluidPage(theme = shinytheme("cerulean"),
    #includeCSS(url("https://raw.githubusercontent.com/pratik0510-p/TE10-Zombean-EcoGhar/main/bootstrap.css?token=AVHUGEABT2XKQPOATDLHAO3BIKZ5K")),
    # Application title
    titlePanel("Plastic footprint calculator"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            div(h3("Food and kitchen need")),
            numericInput("bottles", "Pet bottles disposed per day", value = "0"),
            numericInput("bags", "Plastic Bags disposed per day", value = "0"),
            numericInput("wrappers", "Food wrappers disposed per day", value = "0"),
            numericInput("milk", "dairy containers disposed per week", value = "0"),
            div(h3("Bathroom and laundry")),
            numericInput("swabs", "Cotton swabs disposed per day", value = "0"),
            numericInput("cleaning", "Detergent, cleaning product bottles disposed per week", value = "0"),
            numericInput("cosmetic", "Shampoo / shower gel / cosmetic bottles disposed per week", value = "0"),
            numericInput("refil", "Refill packets disposed per week", value = "0"),
            div(h3("Disposable Containers and Packaging")),
            numericInput("box", "Take-away plastic box disposed per day", value = "0"),
            numericInput("cup", "Take-away plastic cup disposed per day", value = "0"),
            numericInput("straws", "Straws disposed per day", value = "0"),
            numericInput("cutlery", "Disposable cutlary disposed per day", value = "0"),
            numericInput("plates", "Plastic plates disposed per day", value = "0"),
            div(h3("Others")),
            textInput("others", "Toys, furniture etc in kilos disposed per year", value = "0"),),

        # Show a plot of the generated distribution
        mainPanel(
            div(h3("Plastic disposed in kilos per year")),
            plotlyOutput("distPlot", height = 'auto', width = 'auto'),
            infoBoxOutput("simpson",width = 'auto'),
            div(h3("Plastic disposed in kilos for lifetime")),
            plotlyOutput("dist", height = 'auto', width = 'auto'),
            #dataTableOutput("DirMovie_stat"
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
    
    output$distPlot<-renderPlotly({
        bottles <- as.numeric(input$bottles)*0.042*365
        bags <- as.numeric(input$bags)*0.005*365
        wrappers <- as.numeric(input$wrappers)*0.005*365
        milk <- as.numeric(input$milk)*0.062*52.1429
        swabs <- as.numeric(input$swabs)*0.033*365
        cleaning <- as.numeric(input$cleaning)*0.050*52.1429
        cosmetic <- as.numeric(input$cosmetic)*0.050*52.1429
        refil <- as.numeric(input$refil)*0.050*52.1429
        box <- as.numeric(input$box)*0.03*365
        cup <- as.numeric(input$cup)*0.018*365
        straws <- as.numeric(input$straws)*0.008*365
        cutlery <- as.numeric(input$cutlery)*0.010*365
        plates <- as.numeric(input$plates)*0.03*365
        others <- as.numeric(input$others)
        footprint_year <- bottles+bags+wrappers+milk+swabs+cleaning+
            cosmetic+refil+box+cup+straws+cutlery+plates+others
        footprint_lifetime <- footprint_year*80
        fig <- plot_ly(
            type = "indicator",
            mode = "gauge+number+delta",
            value =  footprint_year,
            delta = list(reference = 100, decreasing = list(color = "green"),increasing = list(color = "red")),
            gauge = list(
                axis = list(range = list(0, 500), tickwidth = 1, tickcolor = "blue"),
                bar = list(color = "blue"),
                bgcolor = "white",
                borderwidth = 2,
                bordercolor = "gray",
                steps = list(
                    list(range = c(0, 100), color = "lightgreen"),
                    list(range = c(100, 300), color = "yellow"),
                    list(range = c(300, 500), color = "pink")),
                threshold = list(
                    line = list(color = "red", width = 4),
                    thickness = 0.75,
                    value = 100))) 
        fig <- fig %>%
            layout(
                margin = list(l=20,r=30),
                paper_bgcolor = "lavender",
                font = list(color = "darkblue", family = "Arial"))
        
        fig
        
        
    })
    
    output$simpson <- renderInfoBox({
        bottles <- as.numeric(input$bottles)*0.042*365
        bags <- as.numeric(input$bags)*0.005*365
        wrappers <- as.numeric(input$wrappers)*0.005*365
        milk <- as.numeric(input$milk)*0.062*52.1429
        swabs <- as.numeric(input$swabs)*0.033*365
        cleaning <- as.numeric(input$cleaning)*0.050*52.1429
        cosmetic <- as.numeric(input$cosmetic)*0.050*52.1429
        refil <- as.numeric(input$refil)*0.050*52.1429
        box <- as.numeric(input$box)*0.03*365
        cup <- as.numeric(input$cup)*0.018*365
        straws <- as.numeric(input$straws)*0.008*365
        cutlery <- as.numeric(input$cutlery)*0.010*365
        plates <- as.numeric(input$plates)*0.03*365
        others <- as.numeric(input$others)
        footprint_year <- bottles+bags+wrappers+milk+swabs+cleaning+
            cosmetic+refil+box+cup+straws+cutlery+plates+others
        if (footprint_year < 100){
            value = tags$p("You are in safe limits, your yearly plastic footprint is less than average ", style = "font-size: 200%;")
            infoBox(value)
        }
        else if(between(footprint_year,100,300)) {
            value = tags$p("Beware! The turtles and fishes might get choked you should consider volunteering in the activities", style = "font-size: 200%;")
            infoBox(value)
        }
        else if(between(footprint_year,300,500)) {
            value = tags$p("This much plastic can turn the whole ocean to a graveyard!!! try refuse,reduce and reuse strategy", style = "font-size: 200%;")
            infoBox(value)
        }
        else{
            value = tags$p("This is too much! must find green alternative to plastics or else consider mars!!! ", style = "font-size: 200%;")
            infoBox(value)
        }
    })
    
    output$dist<-renderPlotly({
        bottles <- as.numeric(input$bottles)*0.042*365
        bags <- as.numeric(input$bags)*0.005*365
        wrappers <- as.numeric(input$wrappers)*0.005*365
        milk <- as.numeric(input$milk)*0.062*52.1429
        swabs <- as.numeric(input$swabs)*0.033*365
        cleaning <- as.numeric(input$cleaning)*0.050*52.1429
        cosmetic <- as.numeric(input$cosmetic)*0.050*52.1429
        refil <- as.numeric(input$refil)*0.050*52.1429
        box <- as.numeric(input$box)*0.03*365
        cup <- as.numeric(input$cup)*0.018*365
        straws <- as.numeric(input$straws)*0.008*365
        cutlery <- as.numeric(input$cutlery)*0.010*365
        plates <- as.numeric(input$plates)*0.03*365
        others <- as.numeric(input$others)
        footprint_year <- bottles+bags+wrappers+milk+swabs+cleaning+
            cosmetic+refil+box+cup+straws+cutlery+plates+others
        footprint_lifetime <- footprint_year*80
        fig <- plot_ly(
            type = "indicator",
            mode = "gauge+number+delta",
            value =  footprint_lifetime,
            delta = list(reference = 8000, decreasing = list(color = "green"),increasing = list(color = "red")),
            gauge = list(
                axis = list(range = list(0, 40000), tickwidth = 1, tickcolor = "blue"),
                bar = list(color = "blue"),
                bgcolor = "white",
                borderwidth = 2,
                bordercolor = "gray",
                steps = list(
                    list(range = c(0, 8000), color = "lightgreen"),
                    list(range = c(8000, 24000), color = "yellow"),
                    list(range = c(24000, 40000), color = "pink")),
                threshold = list(
                    line = list(color = "red", width = 4),
                    thickness = 0.75,
                    value = 8000))) 
        fig <- fig %>%
            layout(
                margin = list(l=20,r=30),
                paper_bgcolor = "lavender",
                font = list(color = "darkblue", family = "Arial"))
        
        fig
        
        
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
